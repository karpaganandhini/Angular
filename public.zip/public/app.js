var phonecatApp = angular.module('phonecatApp', ['ngRoute','ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
angular.module('phonecatApp').config(['$locationProvider', '$routeProvider',
    function config($locationProvider, $routeProvider) {
      $locationProvider.hashPrefix('!');

      $routeProvider.
        when('/phones', {
          template: '<phone-list></phone-list>'
        }).
        when('/phones/:phoneId', {
          template: '<phone-detail></phone-detail>'
        }).
        when('/phones/:datepicker', {
          template: '<date-picker></date-picker>'
        }).
        otherwise('/phones');
    }
  ]);
