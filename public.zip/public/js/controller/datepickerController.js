phonecatApp.controller('datepickerController', function() {
  this.myDate = new Date();
  this.isOpen = false;
});
