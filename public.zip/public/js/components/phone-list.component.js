angular.module('phonecatApp').component('phoneList',
        {
        templateUrl: "templates/cardTemplate.html",

      });
